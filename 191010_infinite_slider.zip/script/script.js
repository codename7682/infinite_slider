$(document).ready(function(){
    
    // 1. 초기화
    // #slider의 가로/세로 알아내
    // .slide들한테 그 가로/세로 길이를 주고
    // #bus에게 가로길이를 #slider의 가로길이X(개수+2)    
    // 첫번째/마지막 슬라이드의 내용을 미리 갈무리!!!
    // #bus의 안쪽 내용 마지막 부분에 내용 추가(첫번째슬라이드)  
    // #bus의 안쪽 내용 맨처음 부분에 내용 추가(마지막슬라이드)
    var cur = 0;
    var sliderW = $("#slider").width();
    var sliderH = $("#slider").height();
    var len = $(".slide").length;
    $("#bus").width(sliderW * (len+2));
    var first = $(".slide:first-of-type").html();
    var last = $(".slide:last-of-type").html();
    $("#bus").append("<div class='slide'>"+first+"</div>");
    $("#bus").prepend("<div class='slide'>"+last+"</div>");
    $(".slide").width(sliderW).height(sliderH);
    $("#bus").css("margin-left",(-1)*sliderW+"px");
    // dot 만들기
    for(i=0; i<len; i++){
        $("#pagi").append("<div class='dot'></div>");
    }
    $(".dot").eq(0).addClass("active");
    
    
    // 2. 번호관리부&구동부&페이지액티브관리 [함수]
    function sliding(dir){
        if(!$("#bus").is(":animated")){
            cur = cur + dir;
            $("#bus").stop().animate({
                marginLeft: (-1) * sliderW * (cur+1) +"px"
            },function(){
                if(cur >= len){
                    $("#bus").css("margin-left",(-1)*sliderW+"px");
                    cur = 0;
                }else if(cur <= -1){
                    $("#bus").css("margin-left",(-1)*sliderW*(len)+"px");    
                    cur = len - 1;
                }
                $(".dot").removeClass("active");
                $(".dot").eq(cur).addClass("active");
            });
        }
    }
    
    // 3. 실행부
    $(".left").click(function(){ sliding(-1); });
    $(".right").click(function(){ sliding(1); });
    
    // 4. 페이지네이션 실행부
    $(".dot").click(function(){
        var th = $(this).index();
        cur = 0;
        sliding(th);
    });
    
    
});





































